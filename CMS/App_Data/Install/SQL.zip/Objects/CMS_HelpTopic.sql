SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_HelpTopic](
	[HelpTopicID] [int] IDENTITY(1,1) NOT NULL,
	[HelpTopicUIElementID] [int] NOT NULL,
	[HelpTopicName] [nvarchar](200) NOT NULL,
	[HelpTopicLink] [nvarchar](1023) NOT NULL,
	[HelpTopicLastModified] [datetime2](7) NOT NULL,
	[HelpTopicGUID] [uniqueidentifier] NOT NULL,
	[HelpTopicOrder] [int] NULL,
	[HelpTopicVisibilityCondition] [nvarchar](max) NULL,
 CONSTRAINT [PK_CMS_HelpTopic] PRIMARY KEY CLUSTERED 
(
	[HelpTopicID] ASC
)
)

GO
CREATE NONCLUSTERED INDEX [IX_CMS_HelpTopic_HelpTopicUIElementID] ON [dbo].[CMS_HelpTopic]
(
	[HelpTopicUIElementID] ASC
)
GO
ALTER TABLE [dbo].[CMS_HelpTopic] ADD  CONSTRAINT [DEFAULT_CMS_HelpTopic_HelpTopicName]  DEFAULT (N'') FOR [HelpTopicName]
GO
ALTER TABLE [dbo].[CMS_HelpTopic] ADD  CONSTRAINT [DEFAULT_CMS_HelpTopic_HelpTopicLink]  DEFAULT (N'') FOR [HelpTopicLink]
GO
ALTER TABLE [dbo].[CMS_HelpTopic]  WITH CHECK ADD  CONSTRAINT [FK_CMS_HelpTopic_HelpTopicUIElementID_CMS_UIElement] FOREIGN KEY([HelpTopicUIElementID])
REFERENCES [dbo].[CMS_UIElement] ([ElementID])
GO
ALTER TABLE [dbo].[CMS_HelpTopic] CHECK CONSTRAINT [FK_CMS_HelpTopic_HelpTopicUIElementID_CMS_UIElement]
GO
