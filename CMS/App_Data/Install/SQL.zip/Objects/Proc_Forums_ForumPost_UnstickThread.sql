SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[Proc_Forums_ForumPost_UnstickThread]
@PostForumID int,
@PostID int
AS
BEGIN
	DECLARE @order int;
	SET @order = (SELECT PostStickOrder FROM Forums_ForumPost WHERE PostId = @PostID)

	DECLARE @UpdatedPosts TABLE
	(
		PostId INT
	);

	-- SET  order for new sticky thread
	UPDATE Forums_ForumPost SET PostStickOrder = 0
	OUTPUT INSERTED.PostId INTO @UpdatedPosts
	WHERE PostId = @PostID

	-- Decrement  post order for other posts
	UPDATE Forums_ForumPost SET PostStickOrder = (PostStickOrder - 1)
	OUTPUT INSERTED.PostId INTO @UpdatedPosts
	WHERE PostForumID = @PostForumID AND PostStickOrder > @order

	-- RETURN updated record IDs
	SELECT DISTINCT PostId FROM @UpdatedPosts
END





GO
